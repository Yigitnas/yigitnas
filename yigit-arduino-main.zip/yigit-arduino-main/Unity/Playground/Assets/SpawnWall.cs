﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnWall : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject walls;
    Transform NewWall;
    bool wait;
    void Start()
    {
        wait = true;
 


    }

    // Update is called once per frame
    void Update()  
    {
        if (wait)
            StartCoroutine(SpawnWalls());




    }
    IEnumerator SpawnWalls()
    {
        wait = false; 
        float height = Random.Range(2f, -2f);

        Instantiate(walls, new Vector3(20f, height, walls.transform.position.z), walls.transform.rotation);

        yield return new WaitForSeconds(2.5f);

        wait = true; 


    }
}
