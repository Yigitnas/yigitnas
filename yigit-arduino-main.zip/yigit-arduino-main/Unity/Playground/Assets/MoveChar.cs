﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class MoveChar : MonoBehaviour
{
    public Transform trans;
    public Rigidbody2D rb2;
    public float jump;
    public Score scoreText;
    public GameObject Press;
    public GameObject Restart;
    bool enable;
    bool death; 
    // Start is called before the first frame update
    void Start()
    {
        death = false; 
        enable = false;
        Time.timeScale = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W) && !death ) 
        {
            enable = true; 
            Time.timeScale = 1f;
        }
        if (enable)
        {
            if (Input.GetKey(KeyCode.R))
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }

            if (Input.GetKey(KeyCode.Space))
            {
                rb2.AddForce(new Vector2(0, jump));
            }
            if (Input.GetKey(KeyCode.Escape))
            {
                Application.Quit();
            }
            }

        Press.SetActive(!enable);
        Restart.SetActive(death);
        
        
    }

	private void OnTriggerExit2D(Collider2D collision)
	{
        scoreText.ScoreUp();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Time.timeScale = 0f;
        death = true;
    }
    
}



