﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveObs : MonoBehaviour
{
    public Rigidbody2D rb2;
    public float speed = 10;
    // Start is called before the first frame update
    void Start()
    {
        rb2.velocity = new Vector3(-speed, 0, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if (gameObject.transform.position.x < -10 && gameObject.transform.name == "Walls(Clone)")
        {
            Destroy(gameObject);
        }
        
        
        
    }
}
