#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/* Functions */
void function_name()
{
	// function code
	printf("This is a function");
}

int main()
{
	/*Data Types*/
	int x = 3;			  // integer - tam sayi
	float y = 3.7f;		  // decimal number
	double z = 3.734654f; // longer decimal number - 3.70000000
	y++;				  // x + 1
	y--;				  // x - 1
	y += x;				  // x + y (or any other number)
	y -= x;				  // x -y (or any number)

	bool b = true;												   // boolean - true or false
	char character = 'c';										   // character - single letter
	char name[] = "";											   // string - word
	int numbers[] = {2, 5, 7, 3, 6, 4, 8, 0, 9, 1};				   // "integer" array - list
	printf("Enter name: ");										   //
	scanf("%s", &name);											   // scan input from terminal
	printf("Wake up %s\n", name);								   // print string variable to terminal (\n = newline)
	printf("Variables: %d, %.1f, %lf, %d\n", x, y, z, numbers[5]); // print numeric variables to terminal

	/*
	Bool(Logic) Operations

	== (equal to)
	=/= (not equal to)
	> / < (greater/smaller than)
	>= / <= (great-equal/less-equal than)
	|| (or)
	&& (and) 
	! not
	*/

	/* If Else blocks */
	if ("condition")
	{
		// runs if condition true
	}
	else if ("alternative contition")
	{
		// runs if 1st condition false and alt. condition true
	}
	else
	{
		// runs if all conditions false
	}

	/* Loops */
	for (/* initial operation */; /* looping condition */; /* operation that executes end of the loop */)
	{
		// runs and executes last operation at every loop until condition is true
		break; // breaks the loop ignoring the condition
	}

	while ("condition")
	{
		// runs while condition is true
		break; // breaks the loop ignoring the condition
	}

	do
	{
		// runs 1 time and then checks the condition
		break; // breaks the loop ignoring the condition
	} while ("condition");

	function_name(); // calling a function

	return 0;
}