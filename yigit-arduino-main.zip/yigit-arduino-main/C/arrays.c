#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void printArray(int array[])
{
	for (int i = 0; i < 10; i++)
	{
		printf("%d ", array[i]);
	}
	printf("\n");
}

int maxOfArray(int array[])
{
	int max = 0;
	for (int i = 0; i < 10; i++)
	{
		if (array[i] > max)
		{
			max = array[i];
		}
	}
	return max;
}
int minOfArray(int array[])
{
	int min = array[0];
	for (int i = 1; i < 10; i++)
	{
		if (array[i] < min)
		{
			min = array[i];
		}
	}
	return min;
}

int main()
{ //				 0  1  2  3  4  5  6  7  8  9
	int numbers[] = {2, 5, 7, 3, 6, 4, 8, 7, 9, 1};

	printArray(numbers);
	maxOfArray(numbers);

	int n;
	printf("Enter index: ");
	scanf("%d", &n);

	int x;
	printf("Enter new value: ");
	scanf("%d", &x);
	numbers[n] = x;
	printf("Value changed to %d\n", x);

	printArray(numbers);
	printf("Maximum value is: %d\n", maxOfArray(numbers));
	printf("Minimum value is: %d\n", minOfArray(numbers));
}