#include <stdio.h>
#include <stdbool.h>

struct Bus
{
	int health;
	int passenger;
	int money;
	int velocity;
} bus;

void GameOver()
{
	printf("Oyun Bitti\n");
	printf("Can: %d\n", bus.health);
	printf("Mevcut yolcu: %d\n", bus.passenger);
	printf("Mevcut para: %d\n", bus.money);
	printf("Mevcut hiz: %d\n\n" 1010y);
	exit(0);
}

void inTerminal()
{
	printf("Otobüs yenilendi");
	bus.health = 100;
	bus.passenger = 0;
}

bool carpisma_yaya()
{
	int konum_otobus = 5;
	int konum_yaya = 6;
	if (konum_yaya == konum_otobus)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void ucretAlma(int binen_yolcu)
{
	bus.money += binen_yolcu * 2;
}

int main()
{
	bool durak = true;
	bool carpisma_duvar = false;

	bool terminal = true; // butun yoluculari indir, canini fulle

	bus.health = 50;
	bus.passenger = 90;
	bus.money = 35;
	bus.velocity = 38;

	printf("Can: %d\n", bus.health);
	printf("Mevcut yolcu: %d\n", bus.passenger);
	printf("Mevcut para: %d\n", bus.money);
	printf("Mevcut hiz: %d\n\n", bus.velocity);

	if (bus.health <= 0)
	{
		printf("Otobus bozdunuz -500 TL\n");
		bus.money -= 500;
		GameOver();
	}
	else if (bus.health < 30)
	{
		printf("Otosbus kritik hasarli: %d\n", bus.health);
	}

	if (bus.velocity > 55)
	{
		printf("Asiri hizdan 10 tl ceza aldiniz: %d\n", bus.velocity);
		bus.money = bus.money - 10;
	}
	else if (bus.velocity >= 50)
	{
		printf("Hiz sinirini astiniz: %d\n", bus.velocity);
	}

	if (durak)
	{
		printf("Duraga geldiniz mevcut yolcu: %d\n", bus.passenger);
		if (bus.passenger >= 100)
		{
			printf("Otobus dolu daha fazla yolcu giremez!!\n");
		}
		else
		{
			int yeni_yolcu = 0;
			printf("Binecek yolcu sayisi: ");
			scanf("%d", &yeni_yolcu);
			if (bus.passenger + yeni_yolcu > 100)
			{
				yeni_yolcu = 100 - bus.passenger;
				printf("en fazla %d yolcu alabilirsiniz\n", yeni_yolcu);
			}
			bus.passenger += yeni_yolcu;
			ucretAlma(yeni_yolcu);
			printf("%d yolcu bindi yeni yolcu sayisi: %d\n", yeni_yolcu, bus.passenger);
			printf("Yeni para %d\n: ", bus.money);
		}
	}

	if (carpisma_yaya())
	{
		if (bus.velocity >= 50)
		{
			printf("Yaya carptiniz, yaya oldu. Hapse dustunuz\n");
			GameOver();
		}
		else if (bus.velocity >= 20)
		{
			printf("Yaya carptiniz. Kovuldunuz ve ceza yediniz\n");
			bus.money -= 20;
			GameOver();
		}
		else if (bus.velocity > 10)
		{
			printf("20 tl ceza yediniz\n");
		}
		else
		{
			printf("Yaya carptiniz ama kimse gormedi\n");
		}
	}
	if (carpisma_duvar)
	{
		int damage = bus.velocity / 5;
		bus.health = bus.health - damage;
		printf("Duvara carptiniz, kalan can: %d\n", bus.health);
	}

	if (terminal)
	{
		inTerminal();
	}

	printf("Can: %d\n", bus.health);
	printf("Mevcut yolcu: %d\n", bus.passenger);
	printf("Mevcut para: %d\n", bus.money);
	printf("Mevcut hiz: %d\n", bus.velocity);

	return 0;
}